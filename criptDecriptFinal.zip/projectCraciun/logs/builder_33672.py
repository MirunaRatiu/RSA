# 2024-12-17T17:34:44.688021700
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/projectCraciun")

platform = client.get_component(name="platformCraciun")
status = platform.build()

comp = client.get_component(name="RSA_Craciun")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

