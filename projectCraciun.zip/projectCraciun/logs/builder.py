# 2024-12-17T18:26:46.553613500
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/projectCraciun")

vitis.dispose()

platform = client.get_component(name="platformCraciun")
status = platform.build()

comp = client.get_component(name="RSA_Craciun")
comp.build()

status = platform.build()

comp.build()

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/projectCraciun/design_Craciun_wrapper.xsa")

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/projectCraciun/design_Craciun_wrapper.xsa")

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/design_2_wrapper.xsa")

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/proiectCraciun/design_2_wrapper.xsa")

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/platformaUltima/design_3_wrapper.xsa")

status = platform.update_hw(hw_design = "C:/Users/Miruna/Documents/POLI/an3/SSC/platformaUltima/design_3_wrapper.xsa")

vitis.dispose()

vitis.dispose()

